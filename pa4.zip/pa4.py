#------------------------- 10% -------------------------------------
# The operand stack: define the operand stack and its operations
opstack = []

# now define functions to push and pop values to the top of to/from the top of the stack (end of the list). Recall that `pass` in Python is a space holder: replace it with your code.

def opPop():
	return opstack.pop()

def opPush(value):
	opstack.append(value)

# Remember that there is a Postscript operator called "pop" so we choose different names for these functions.

#-------------------------- 20% -------------------------------------
# The dictionary stack: define the dictionary stack and its operations

dictstack = []

# now define functions to push and pop dictionaries on the dictstack, to define name, and to lookup a name

def dictPop():
	return dictstack.pop()
# dictPop pops the top dictionary from the dictionary stack.

def dictPush(): 
	dictstack.append(opPop())

def dictPush(d):
	dictstack.append(d)
#dictPush pushes a new dictionary to the dictstack. Note that, your interpreter will call dictPush only when Postscript “begin” operator is called. “begin” should pop the empty dictionary 
#from the opstack and push it onto the dictstack by calling dictPush. You may either pass this dictionary (which you popped from opstack) to dictPush as a parameter or just simply push a new empty dictionary in dictPush.

def define(name, value):
	temp = dictstack[len(dictstack)-1]
	temp[name] = value
#add name:value to the top dictionary in the dictionary stack. (Keep the ‘/’ in name when you add it to the top dictionary) Your psDef function should pop the name and value from operand stack and call the “define” function.

def lookup(name):
	for i in dictstack:
		for j in i:
			if j == name:
				return i[j]
	print("Error: key not found in dictionary stack.")
	return None
# return the value associated with name.
# What is your design decision about what to do when there is no definition for
# name? If “name” is not defined, your program should not break, but should
# give an appropriate error message.

#--------------------------- 15% -------------------------------------
# Arithmetic and comparison operators: define all the arithmetic and comparison operators here -- add, sub, mul, div, eq, lt, gt
#Make sure to check the operand stack has the correct number of parameters and types of the parameters are correct. 
def add ():
	if len(opstack) >= 2:
		var1 = opstack[len(opstack)-1]
		var2 = opstack[len(opstack)-2]
		if isinstance(var1, int) and isinstance(var2, int):
			var1 = opPop()
			var2 = opPop()
			opPush(var1+var2)
			return var1+var2
		else:
			print("Error: incompatable types")
	else:
		print("Error: not enough operands on stack")
	return None
			
def sub ():
	if len(opstack) >= 2:
		var1 = opstack[len(opstack)-1]
		var2 = opstack[len(opstack)-2]
		if isinstance(var1, int) and isinstance(var2, int):
			var1 = opPop()
			var2 = opPop()
			opPush(var2-var1)
			return var2-var1
		else:
			print("Error: incompatable types")
	else:
		print("Error: not enough operands on stack")
	return None
			
def mul ():
	if len(opstack) >= 2:
		var1 = opstack[len(opstack)-1]
		var2 = opstack[len(opstack)-2]
		if isinstance(var1, int) and isinstance(var2, int):
			var1 = opPop()
			var2 = opPop()
			opPush(var2*var1)
			return var2*var1
		else:
			print("Error: incompatable types")
	else:
		print("Error: not enough operands on stack")
	return None
			
def div ():
	if len(opstack) >= 2:
		var1 = opstack[len(opstack)-1]
		var2 = opstack[len(opstack)-2]
		if isinstance(var1, int) and isinstance(var2, int):
			var1 = opPop()
			var2 = opPop()
			opPush(var2/var1
			return var2/var1
		else:
			print("Error: incompatable types")
	else:
		print("Error: not enough operands on stack")
	return None
	
def eq ():
	if len(opstack) >= 2:
		var1 = opstack[len(opstack)-1]
		var2 = opstack[len(opstack)-2]
		if type(var1) == type(var2):
			opPush(var1 == var2)
			return var1==var2
		else:
			print("Error: incompatable types")
	else:
		print("Error: not enough operands on stack")
	return None
	
def lt ():
	if len(opstack) >= 2:
		var1 = opstack[len(opstack)-1]
		var2 = opstack[len(opstack)-2]
		if type(var1) == type(var2):
			opPush(var1 > var2)
			return var1 > var2
		else:
			print("Error: incompatable types")
	else:
		print("Error: not enough operands on stack")
	return None
	
def gt ():
	if len(opstack) >= 2:
		var1 = opstack[len(opstack)-1]
		var2 = opstack[len(opstack)-2]
		if type(var1) == type(var2):
			opPush(var1 < var2)
			return var1 < var2
		else:
			print("Error: incompatable types")
	else:
		print("Error: not enough operands on stack")
	return None
#--------------------------- 15% -------------------------------------
# Array operators: define the array operators length, get
def length():
	if len(opstack >= 1):
		var1 = opstack[len(opstack)-1]
		if isinstance(var1, list):
			temp = len(opPop())
			opPush(temp)
			return temp
		else:
			print("Error: operand is not an array")
	else:
		print("Error: not enough operands on stack")
	return None

def get():
	if len(opstack) >= 2:
		var1 = opstack[len(opstack)-1]
		var2 = opstack[len(opstack)-2]
		if isinstance(var1, int) and isinstance(var2, list):
			var1 = opPop()
			var2 = opPop()
			opPush(var2[var1])
			return var2[var1]
		else:
			print("Error: incompatable types")
	else:
		print("Error: not enough operands on stack")
	return None
#--------------------------- 15% -------------------------------------
# Boolean operators: define the boolean operators psAnd, psOr, psNot Remember that these take boolean operands only. Anything else is an error
def psAnd():
	if len(opstack) >= 2:
		var1 = opstack[len(opstack)-1]
		var2 = opstack[len(opstack)-2]
		if isinstance(var1, bool) and isinstance(var2, bool):
			var1 = opPop()
			var2 = opPop()
			opPush(var1 and var2)
			return var1 and var2
		else:
			print("Error: incompatable types")
	else:
		print("Error: not enough operands on stack")
	return None
	
def psOr():
	if len(opstack) >= 2:
		var1 = opstack[len(opstack)-1]
		var2 = opstack[len(opstack)-2]
		if isinstance(var1, bool) and isinstance(var2, bool):
			var1 = opPop()
			var2 = opPop()
			opPush(var1 or var2)
			return var1 or var2
		else:
			print("Error: incompatable types")
	else:
		print("Error: not enough operands on stack")
	return None
	
def psNot():
	if len(opstack) >= 1:
		var1 = opstack[len(opstack)-1]
		if isinstance(var1, bool):
			var1 = opPop()
			opPush(not var1)
			return not var1
		else:
			print("Error: incompatable types")
	else:
		print("Error: not enough operands on stack")
	return None

#--------------------------- 25% -------------------------------------
# Define the stack manipulation and print operators: dup, exch, pop, copy, clear, stack
def dup():
	if len(opstack) >= 1:
		var1 = opstack[len(opstack)-1]
		opPush(var1)
	else:
		print("Error: not enough operands on stack")
	return None
	
def exch():
	if len(opstack) >= 2:
		var1 = opPop()
		var2 = opPop()
		opPush(var1)
		opPush(var2)
	else:
		print("Error: not enough operands on stack")
	return None
		
def pop():
	if len(opstack) >= 1:
		opPop()
	else:
		print("Error: not enough operands on stack")
	return None
		
def copy():
	if len(opstack) >= 2:
		n = opPop();
		if isinstance(n, int):
			temp = []
			for i in range(n):
				temp.append(opPop())
			for i in range(n):
				opPush(temp.pop())
		else:
			print("Error: incompatable operands")
	else:
		print("Error: not enough operands on stack")
	return None

def clear():
	opstack.clear()
	return None
	
def stack():
	for i in range(len(opstack)):
		print(opstack[i])
	return None

#--------------------------- 20% -------------------------------------
# Define the dictionary manipulation operators: psDict, begin, end, psDef
# name the function for the def operator psDef because def is reserved in Python.
# Note: The psDef operator will pop the value and name from the opstack and call your own "define" operator (pass those values as parameters). Note that psDef()won't have any parameters.

def psDict():
	if len(opstack) >= 1:
		opPop()
		dictstack.append({})
	else:
		print("Error: not enough operands on stack")
	return None

def begin():
	if len(opstack) >= 1:
		var1 = opstack[len(opstack)-1]
		if isinstance(var1, dict):
			dictPush(opPop())
	else:
		print("Error: not enough operands on stack")
	return None
	
def end():
	dictPop()
	
def psDef():
	if len(opstack) >= 2:
		value = opPop()
		key = opPop()
		define(key, value)
	else:
		print("Error: not enough operands on stack")
	return None

#--------------------------- TEST FUNCTIONS -----------------------------------
# Include your test functions here
def testAdd():
	opPush(1)
	opPush(2)
	add()
	return (opPop() == 3)
	
def testSub():
	opPush(2)
	opPush(1)
	sub()
	return (opPop() == 1)
	
def testMul():
	opPush(4)
	opPush(3)
	mul()
	return(opPop() == 12)
	
def testDiv():
	opPush(12)
	opPush(3)
	div()
	return(opPop() == 4)
	
def testEq():
	opPush(4)
	opPush(4)
	eq()
	return (opPop() == True)
	
def testLt():
	opPush(2)
	opPush(4)
	lt()
	return (opPop() == True)
	
def testGt():
	opPush(4)
	opPush(2)
	gt()
	return (opPop() == True)
	
def testLength():
	opPush([1,2,3,4])
	length()
	return (opPop() == 4)
	
def testPsAnd():
	opPush(True)
	opPush(True)
	psAnd()
	return (opPop())
	
def testPsOr():
	opPush(True)
	opPush(False)
	psOr()
	return(opPop())
	
def testPsNot():
	opPush(False)
	psNot()
	return(opPop())
	
def testpsDef():
	opPush("\n1")
	opPush(3)
	psDef()
	return (lookup("n1") == 3)


if __name__ == '__main__':
	# add you test functions to this list along with suitable names
	testCases = [('add', testAdd()), ('sub', testSub()), ('mul', testMul()), ('div', testDiv()), ('eq', testEq()), ('lt', testLt()), ('gt', testGt()), ('length', testLength()), ('psAnd', testPsAnd()), 
	('testPsOr', testPsOr()), ('psNot', testPsNot()), ('psDef', testpsDef())]
	
	failedTests = [testName for (testName, testProc) in testCases if not testProc()]
	if failedTests:
		return ('Some tests failed', failedTests)
	else:
		return ('All tests OK') 